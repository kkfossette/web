# 学生管理系统 StudentManagement

## 简介N
* 开发工具：Oracle jdk8,MySQL数据库 Mac计算机，Windows计算机，Netbeans8，Eclipse。
* 项目其中的很多类可复用，基于此可很快完成一个新的管理系统。
* 前半段在netbeans上开发的，后面完善是在eclipse，eclipse可完美运行，netbeans也可以。
* 编码为GBK。
* 数据库文件在database文件夹
* 2019.6.21 重写了界面，优化了代码，增加了更多提示信息...
* 界面可以来[博客](https://blog.csdn.net/Just_learn_more/article/details/91867917)看.....

## 实现的功能
* 用户登录注册
* 学生管理：增删改查等等...
* 数据表导出excel功能没完成，有时间写一下(不想写了...

## 点个星星吧
